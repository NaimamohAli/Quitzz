import express from "express";
import dotenv from "dotenv";
import { connectDB } from "./config/db";

dotenv.config();
const app = express();

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.post("/api/quizes", async (req, res) => {
  // Logic to create a new quiz
  const quiz = req.body;
  if (!quiz) {
    return res.status(400).json({ message: "Quiz data is required" });
  }

  const newQuiz = new Quiz(quiz);
  try {
    await newQuiz.save();
    res
      .status(201)
      .json({ message: "Quiz created successfully", quiz: newQuiz });
  } catch (error) {
    console.error("Error creating quiz:", error);
    return res
      .status(500)
      .json({ success: false, message: "Error creating quiz", error });
  }
  // Assuming you have a Quiz model defined in your models directory
  res.status(201).json({ message: "Quiz created successfully" });
});
/*app.get("/api/quizes", (req, res) => {});
app.get("/api/quizes/:id", (req, res) => {});   
app.put("/api/quizes/:id", (req, res) => {});
app.delete("/api/quizes/:id", (req, res) => {});
app.post("/api/quizes/:id/answers", (req, res) => {});
app.get("/api/quizes/:id/answers", (req, res) => {});*/

app.listen(3000, () => {
  connectDB();
  console.log("Server is running on port 3000");
});
